package com.tssa.km.domain;

public class TestResult {

}
