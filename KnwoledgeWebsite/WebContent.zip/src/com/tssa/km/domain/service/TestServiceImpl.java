package com.tssa.km.domain.service;

import java.util.List;

import com.tssa.km.domain.TestResult;

public class TestServiceImpl implements TestService {

	@Override
	public TestResult save() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TestResult> getList() {
		// TODO Auto-generated method stub
		return null;
	}

}
