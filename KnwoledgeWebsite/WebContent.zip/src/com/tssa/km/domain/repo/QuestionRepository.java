package com.tssa.km.domain.repo;

import java.util.List;

import com.tssa.km.domain.hibernate.QuestionCategory;
import com.tssa.km.domain.hibernate.QuestionExt;
public interface QuestionRepository {
	List<QuestionExt> getQuestionList();
	List<QuestionCategory> getQuestionCategories();
}
