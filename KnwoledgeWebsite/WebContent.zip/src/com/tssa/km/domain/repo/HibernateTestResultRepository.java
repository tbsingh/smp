package com.tssa.km.domain.repo;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.tssa.km.domain.TestResult;
import com.tssa.km.domain.hibernate.QuestionCategory;
import com.tssa.km.domain.hibernate.QuestionExt;

public class HibernateTestResultRepository extends HibernateDaoSupport implements TestResultRepository {

//	@SuppressWarnings("unchecked")
//	@Override
//	public List<QuestionExt> getQuestionList() {
//		return getHibernateTemplate().findByNamedQuery("question.listAll");
//	}
//
//	@Override
//	public List<QuestionCategory> getQuestionCategories() {
//		return getHibernateTemplate().findByNamedQuery("question.category.listAll");
//	}

	@Override
	public TestResult save() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TestResult> getList() {
		// TODO Auto-generated method stub
		return null;
	}

}
