package com.tssa.km.domain.repo;

import java.util.List;

import com.tssa.km.domain.TestResult;
public interface TestResultRepository {
	TestResult save();
	List<TestResult> getList();
}
