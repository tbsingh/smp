package com.tssa.km.web.command;

public class AgreementCommand {
	private String pageTitle="TEST YOUR SKILLS ONLINE";
	private String testType;
	public String getTestType() {
		return testType;
	}
	public void setTestType(String testType) {
		this.testType = testType;
	}
	public AgreementCommand(){}
	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
}
