package com.tssa.km.web.command;

import java.util.Map;

public class TestResultCommand {
	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
	private Map<String, Integer>result;
	public Map<String, Integer> getResult() {
		return result;
	}

	public void setResult(Map<String, Integer> result) {
		this.result = result;
	}
	private String pageTitle;
	private int score;
	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

}
