package com.tssa.km.web.command;

public class KnowledgeCommand {
	private String pageTitle="Skill Management Platform";
	public KnowledgeCommand(){}
	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
}
