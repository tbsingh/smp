package com.tssa.km.web.command;

public class RegistrationCommand {
	public RegistrationCommand(){
		firstName="";
		secondName="";
		emailAddress="";
		pageTitle="TEST YOUR SKILLS ONLINE";
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSecondName() {
		return secondName;
	}
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	private String pageTitle;
	public String getPageTitle() {
		return pageTitle;
	}
	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
	private String firstName;
	private String secondName;
	private String emailAddress;

}
